# main.py
from flask import Flask, Response, request, send_from_directory
from flask_socketio import SocketIO, emit, join_room, leave_room
import os
import datetime
import json
import re
import shutil # For clearing uploads directory

app = Flask(__name__)

# --- Configuration for Production ---
# Use environment variables for sensitive data and dynamic configurations
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'a_very_secret_and_long_key_for_as_chat_app_by_your_name_CHANGE_THIS_IN_PROD')
# It's crucial to set this to a strong, unique value in your production environment variables.

# Host password should also be from environment variable for security
HOST_PASSWORD = os.environ.get('HOST_PASSWORD', 'my_secret_host_key_CHANGE_THIS_FOR_PRODUCTION!') 
# IMPORTANT: Never use 'my_secret_host_key_CHANGE_THIS_FOR_PRODUCTION!' in production.
# Set a strong, unique password via your hosting platform's environment variables.

# Adjust SocketIO for production deployment (e.g., eventlet/gevent, message queues)
# For simple deployments, you might not need an explicit message_queue if sticky sessions are supported.
# For scaled deployments, a message queue (like Redis) is essential.
# Example with Redis:
# socketio = SocketIO(app, message_queue=os.environ.get('REDIS_URL', 'redis://localhost:6379/0'))
socketio = SocketIO(app) # For basic deployment without explicit message queue config

CHAT_ROOM = "main_as_chat_room"

hosts = set() # Stores session IDs of current hosts
muted_users = set() # Stores session IDs of individual muted users
chat_disabled_for_all = False # New flag to disable chat for everyone (except host)

# Stores user information (sid: {username, is_host, is_muted})
user_info = {}

# --- Video Sharing Setup ---
# Use an absolute path for UPLOAD_FOLDER for better compatibility across different hosting environments.
# Ensure your hosting platform allows writing to this directory and it persists across restarts if needed.
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# To store the path of the currently shared video on the server
current_shared_video_server_path = None

# --- Frontend HTML, CSS, JavaScript as Python strings ---
# It's generally better practice to serve these from static files (e.g., a 'static' folder)
# in production, letting the web server (Nginx, Apache) handle them efficiently.
# However, for a single-file Flask app, keeping them as strings is acceptable for small scale.

CSS_CONTENT = """
/* GIF Sticker Overlay */
.gif-overlay {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 9999;
    pointer-events: none;
    opacity: 1;
    transition: opacity 0.5s ease-out;
    max-width: 300px;
    max-height: 300px;
    border-radius: 15px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.6);
}

.gif-overlay img {
    width: 100%;
    height: auto;
    border-radius: 15px;
    border: 3px solid var(--primary-purple);
}

.gif-overlay.fade-out {
    opacity: 0;
}

/* General Styling */
:root {
    --primary-purple: #7B2CBF;     /* Deep Purple */
    --dark-purple: #5A189A;        /* Darker Purple */
    --light-purple: #C77DFF;       /* Light Purple */
    --accent-blue: #4C9AFF;        /* Bright Blue */
    --dark-blue: #2962FF;          /* Dark Blue */
    --background-black: #0D1117;   /* Deep Black Background */
    --surface-black: #161B22;      /* Slightly lighter black for surfaces */
    --border-black: #21262D;       /* Border black */
    --text-light: #E6EEFF;         /* Light text */
    --text-medium: #B8C4D9;        /* Medium text */
    --white: #FFFFFF;
    --black: #000000;
    --error-red: #FF4757;
    --success-green: #2ED573;
    --warning-orange: #FFA502;
    --gradient-primary: linear-gradient(135deg, #7B2CBF 0%, #4C9AFF 100%);
    --gradient-surface: linear-gradient(135deg, #161B22 0%, #21262D 100%);

    --border-radius-soft: 12px;
    --border-radius-round: 25px;
    --box-shadow-light: 0 8px 32px rgba(123, 44, 191, 0.15);
    --box-shadow-heavy: 0 12px 40px rgba(0, 0, 0, 0.4);
    --transition-speed: 0.3s ease;
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding: 0;
    background: var(--background-black);
    background-image: 
        radial-gradient(circle at 20% 20%, rgba(123, 44, 191, 0.1) 0%, transparent 50%),
        radial-gradient(circle at 80% 80%, rgba(76, 154, 255, 0.1) 0%, transparent 50%),
        radial-gradient(circle at 40% 60%, rgba(90, 24, 154, 0.05) 0%, transparent 50%);
    color: var(--text-light);
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    font-size: 16px;
    line-height: 1.6;
    overflow-x: hidden;
    padding: 10px;
}

.container {
    background: var(--gradient-surface);
    border-radius: var(--border-radius-soft);
    box-shadow: var(--box-shadow-heavy);
    border: 1px solid var(--border-black);
    width: 95%;
    max-width: 1400px;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    min-height: 90vh;
    margin: auto;
    backdrop-filter: blur(10px);
}

/* Header */
header {
    background: var(--gradient-primary);
    color: var(--white);
    padding: 20px 15px;
    text-align: center;
    border-bottom: 3px solid var(--dark-purple);
    box-shadow: 0 4px 20px rgba(123, 44, 191, 0.3);
    position: relative;
    overflow: hidden;
}

header::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
    animation: shimmer 3s infinite;
}

@keyframes shimmer {
    0% { left: -100%; }
    100% { left: 100%; }
}

.logo {
    font-size: 2.5em; /* Smaller logo for mobile */
    font-weight: bold;
    margin-bottom: 5px;
    letter-spacing: 1px; /* Slightly reduced letter spacing */
    text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
}

h1 {
    color: var(--white);
    margin-top: 5px;
    font-size: 1.5em; /* Smaller H1 for mobile */
}

h2, h3, h4 {
    color: var(--light-purple);
    margin-top: 0;
    margin-bottom: 15px;
    font-weight: 600;
}

h2 { 
    font-size: 1.6em;
    background: var(--gradient-primary);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}
h3 { 
    font-size: 1.2em;
    color: var(--accent-blue);
}
h4 { 
    font-size: 1em; 
    color: var(--text-medium);
}


/* Main Content Layout - Mobile First */
.main-content {
    display: flex;
    flex-direction: column; /* Stack panels vertically by default */
    padding: 15px; /* Reduced padding */
    gap: 15px; /* Reduced gap */
    flex-grow: 1;
    overflow-y: auto; /* Allow scrolling if content overflows */
}

.video-panel, .chat-panel {
    background: var(--surface-black);
    border-radius: var(--border-radius-soft);
    padding: 15px;
    box-shadow: inset 0 2px 10px rgba(0,0,0,0.3);
    border: 1px solid var(--border-black);
    display: flex;
    flex-direction: column;
    position: relative;
}

.video-panel::before, .chat-panel::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 1px;
    background: var(--gradient-primary);
    opacity: 0.5;
}

.video-panel {
    flex-grow: 1; /* Allow video panel to grow */
}

.chat-panel {
    flex-grow: 1; /* Allow chat panel to grow */
}


/* Video Player */
.video-container {
    position: relative;
    width: 100%;
    padding-top: 56.25%; /* 16:9 Aspect Ratio */
    background-color: var(--black);
    border-radius: var(--border-radius-soft);
    overflow: hidden;
    margin-bottom: 10px; /* Reduced margin */
    border: 1px solid var(--silver-medium);
}

.video-container video {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: contain;
    background-color: var(--black);
}

.video-placeholder {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: var(--silver-dark);
    font-style: italic;
    font-size: 1em; /* Smaller font size */
    text-align: center;
    text-shadow: 1px 1px 2px rgba(0,0,0,0.4);
}

/* Chat Box */
.message-box {
    border: 1px solid var(--border-black);
    border-radius: var(--border-radius-soft);
    height: 300px;
    overflow-y: auto;
    padding: 10px;
    background: var(--background-black);
    margin-bottom: 10px;
    display: flex;
    flex-direction: column;
    gap: 8px;
    box-shadow: inset 0 2px 8px rgba(0,0,0,0.4);
}

.message {
    background: linear-gradient(135deg, var(--dark-purple) 0%, var(--primary-purple) 100%);
    color: var(--white);
    padding: 8px 12px;
    border-radius: var(--border-radius-round);
    max-width: 90%;
    align-self: flex-start;
    word-wrap: break-word;
    box-shadow: 0 2px 8px rgba(123, 44, 191, 0.3);
    transition: all 0.3s ease;
    font-size: 0.9em;
    border: 1px solid rgba(199, 125, 255, 0.3);
}

.message:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(123, 44, 191, 0.4);
}

.message.system {
    background: linear-gradient(135deg, var(--accent-blue) 0%, var(--dark-blue) 100%);
    color: var(--white);
    text-align: center;
    font-style: italic;
    max-width: 100%;
    align-self: center;
    padding: 6px 10px;
    border-radius: var(--border-radius-soft);
    box-shadow: 0 2px 6px rgba(76, 154, 255, 0.3);
    font-size: 0.85em;
    border: 1px solid rgba(76, 154, 255, 0.4);
}

.message.error {
    background: linear-gradient(135deg, var(--error-red) 0%, #FF3742 100%);
    color: var(--white);
    text-align: center;
    font-weight: bold;
    padding: 6px 10px;
    border-radius: var(--border-radius-soft);
    font-size: 0.85em;
    border: 1px solid rgba(255, 71, 87, 0.4);
}

.message .username {
    font-weight: bold;
    color: var(--light-purple);
    margin-bottom: 2px;
    display: block;
    font-size: 0.8em;
    text-shadow: 0 1px 2px rgba(0,0,0,0.3);
}

.message-box .my-sid-display {
    text-align: center;
    font-size: 0.75em;
    color: var(--text-medium);
    margin-bottom: 10px;
    padding: 8px;
    border-bottom: 1px dashed var(--border-black);
    background: var(--surface-black);
    border-radius: var(--border-radius-soft);
    border: 1px solid var(--border-black);
}

/* Form Controls */
.input-area, .host-auth-area, .host-controls-section, .user-mute-controls {
    display: flex;
    flex-direction: column; /* Stack inputs/buttons vertically by default */
    gap: 10px; /* Reduced gap */
    margin-top: 10px;
    flex-wrap: wrap;
    align-items: stretch; /* Stretch items to full width */
}

.text-input, .file-input {
    width: 100%;
    padding: 12px 16px;
    border: 1px solid var(--border-black);
    border-radius: var(--border-radius-round);
    font-size: 1em;
    background: var(--surface-black);
    color: var(--text-light);
    outline: none;
    transition: all var(--transition-speed);
    box-shadow: inset 0 2px 4px rgba(0,0,0,0.3);
}

.text-input:focus, .file-input:focus {
    border-color: var(--primary-purple);
    box-shadow: 0 0 0 3px rgba(123, 44, 191, 0.25);
    background: var(--background-black);
}

.text-input::placeholder {
    color: var(--text-medium);
}

.btn {
    width: 100%;
    padding: 12px 24px;
    border: none;
    border-radius: var(--border-radius-round);
    cursor: pointer;
    font-size: 1em;
    font-weight: bold;
    transition: all var(--transition-speed);
    white-space: nowrap;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    position: relative;
    overflow: hidden;
}

.btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
    transition: left 0.5s;
}

.btn:hover::before {
    left: 100%;
}

.btn-primary { 
    background: var(--gradient-primary);
    color: var(--white);
    box-shadow: 0 4px 15px rgba(123, 44, 191, 0.3);
}
.btn-primary:hover { 
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(123, 44, 191, 0.4);
}

.btn-secondary { 
    background: linear-gradient(135deg, var(--surface-black) 0%, var(--border-black) 100%);
    color: var(--text-light);
    border: 1px solid var(--border-black);
}
.btn-secondary:hover { 
    background: linear-gradient(135deg, var(--border-black) 0%, var(--surface-black) 100%);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
}

.btn-danger { 
    background: linear-gradient(135deg, var(--error-red) 0%, #FF3742 100%);
    color: var(--white);
    box-shadow: 0 4px 15px rgba(255, 71, 87, 0.3);
}
.btn-danger:hover { 
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(255, 71, 87, 0.4);
}

.btn-warning { 
    background: linear-gradient(135deg, var(--warning-orange) 0%, #FF9500 100%);
    color: var(--background-black);
    box-shadow: 0 4px 15px rgba(255, 165, 2, 0.3);
}
.btn-warning:hover { 
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(255, 165, 2, 0.4);
}

.btn-info { 
    background: linear-gradient(135deg, var(--accent-blue) 0%, var(--dark-blue) 100%);
    color: var(--white);
    box-shadow: 0 4px 15px rgba(76, 154, 255, 0.3);
}
.btn-info:hover { 
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(76, 154, 255, 0.4);
}


/* Host specific styles */
.host-controls-section {
    border-top: 1px dashed var(--border-black);
    padding-top: 15px;
    margin-top: 20px;
    flex-direction: column;
    align-items: stretch;
}

.host-controls-section h3, .host-controls-section h4 {
    margin-bottom: 10px;
    text-align: center;
}

.user-mute-controls {
    flex-direction: column;
    margin-top: 10px;
    padding: 15px;
    background: var(--background-black);
    border-radius: var(--border-radius-soft);
    box-shadow: inset 0 2px 6px rgba(0,0,0,0.4);
    border: 1px solid var(--border-black);
}

.user-list {
    list-style: none;
    padding: 0;
    max-height: 150px;
    overflow-y: auto;
    border: 1px solid var(--border-black);
    border-radius: var(--border-radius-soft);
    margin-bottom: 10px;
    background: var(--surface-black);
}

.user-list li {
    padding: 8px 12px;
    border-bottom: 1px solid var(--border-black);
    font-size: 0.9em;
    color: var(--text-light);
    transition: background-color 0.2s ease;
}

.user-list li:hover {
    background: var(--background-black);
}

.user-list li:last-child {
    border-bottom: none;
}

/* Feedback messages */
.feedback-message {
    padding: 12px;
    border-radius: var(--border-radius-soft);
    margin-top: 10px;
    text-align: center;
    font-weight: bold;
    opacity: 1;
    transition: all 0.5s ease-out;
    border: 1px solid;
}

.feedback-message.success {
    background: linear-gradient(135deg, var(--success-green) 0%, #2ED573 100%);
    color: var(--white);
    border-color: rgba(46, 213, 115, 0.4);
    box-shadow: 0 4px 15px rgba(46, 213, 115, 0.3);
}

.feedback-message.error {
    background: linear-gradient(135deg, var(--error-red) 0%, #FF3742 100%);
    color: var(--white);
    border-color: rgba(255, 71, 87, 0.4);
    box-shadow: 0 4px 15px rgba(255, 71, 87, 0.3);
}

/* Media Queries for Larger Screens (Tablet and Desktop) */
@media (min-width: 768px) {
    .container {
        width: 90%; /* Slightly wider on tablets */
        min-height: 85vh; /* Adapt height for larger screens */
    }

    header {
        padding: 25px 20px;
    }

    .logo {
        font-size: 3em;
        letter-spacing: 2px;
    }

    h1 {
        font-size: 1.8em;
    }

    h2 { font-size: 1.8em; }
    h3 { font-size: 1.4em; }
    h4 { font-size: 1.1em; }

    .main-content {
        flex-direction: row; /* Layout panels side-by-side on larger screens */
        padding: 25px;
        gap: 25px;
    }

    .video-panel, .chat-panel {
        flex: 1; /* Distribute space equally */
        min-width: 380px; /* Minimum width for panels */
        padding: 20px;
    }

    .video-panel {
        flex-grow: 2; /* Video panel takes more space */
    }

    .chat-panel {
        flex-grow: 1;
    }

    .message-box {
        height: 400px; /* Taller message box on larger screens */
        padding: 15px;
        gap: 10px;
    }

    .message {
        padding: 10px 15px;
        font-size: 1em;
        max-width: 85%;
    }
    .message.system, .message.error {
        padding: 8px 12px;
        font-size: 0.9em;
    }
    .message .username {
        font-size: 0.9em;
    }

    .video-placeholder {
        font-size: 1.2em;
    }

    .input-area, .host-auth-area {
        flex-direction: row; /* Arrange horizontally on larger screens */
        gap: 10px;
    }
    .text-input, .file-input {
        width: auto; /* Allow them to shrink/grow based on content */
    }
    .btn {
        width: auto; /* Allow buttons to shrink/grow based on content */
    }

    .host-controls-section, .user-mute-controls {
        flex-direction: column; /* Keep stacked for controls clarity */
    }
}

/* Specific adjustments for very small screens (e.g., old phones) */
@media (max-width: 480px) {
    body {
        padding: 5px;
    }
    .container {
        width: 100%;
        min-height: 95vh;
        margin: 0; /* Remove margin to use full width */
        border-radius: 0; /* No border radius on very small screens for full coverage */
        box-shadow: none; /* No shadow */
    }
    header {
        padding: 15px 10px;
        border-radius: 0;
    }
    .logo {
        font-size: 2em;
    }
    h1 {
        font-size: 1.3em;
    }
    .main-content {
        padding: 10px;
        gap: 10px;
    }
    .video-panel, .chat-panel {
        padding: 10px;
    }
    .message-box {
        height: 250px; /* Even smaller message box on very small screens */
        padding: 8px;
        gap: 5px;
    }
    .message {
        padding: 6px 10px;
        font-size: 0.85em;
    }
    .message.system, .message.error {
        padding: 5px 8px;
        font-size: 0.8em;
    }
    .message .username {
        font-size: 0.75em;
    }
    .text-input, .file-input, .btn {
        font-size: 0.9em;
        padding: 8px 12px;
    }
}
"""

JS_CONTENT = """
const socket = io();

const messagesDiv = document.getElementById('messages');
const usernameInput = document.getElementById('usernameInput');
const messageInput = document.getElementById('messageInput');
const sendMessageBtn = document.getElementById('sendMessage');
const sharedVideo = document.getElementById('sharedVideo');
const videoFileInput = document.getElementById('videoFileInput');
const startVideoShareBtn = document.getElementById('startVideoShare');
const clearSharedVideoBtn = document.getElementById('clearSharedVideo');
const hostPasswordInput = document.getElementById('hostPasswordInput');
const authenticateHostBtn = document.getElementById('authenticateHost');
const hostAuthFeedback = document.getElementById('hostAuthFeedback');
const hostVideoControlsDiv = document.getElementById('hostVideoControls');
const hostChatControlsDiv = document.getElementById('hostChatControls');
const muteUserIdInput = document.getElementById('muteUserId');
const toggleMuteBtn = document.getElementById('toggleMute');
const toggleChatEnabledBtn = document.getElementById('toggleChatEnabled');
const connectedUsersList = document.getElementById('connectedUsersList');
const videoContainer = document.getElementById('videoContainer');
const noVideoMessage = document.getElementById('noVideoMessage');

let isHost = false;
let isChatEnabled = true;

// GIF sticker mappings
const gifStickers = {
    'cry': 'https://d.top4top.io/p_3445hvt6b1.gif',
    'bored': 'https://h.top4top.io/p_3445t9ure1.gif',
    'sorry': 'https://e.top4top.io/p_34458caai1.gif',
    'sama': 'https://a.top4top.io/p_344583fu51.gif',
    'among': 'https://j.top4top.io/p_3445pekfp1.gif',
    'bic': 'https://f.top4top.io/p_34451mulq1.gif'
};

function showGifSticker(keyword) {
    const gifUrl = gifStickers[keyword.toLowerCase()];
    if (!gifUrl) return;

    // Remove any existing gif overlays
    const existingOverlays = document.querySelectorAll('.gif-overlay');
    existingOverlays.forEach(overlay => overlay.remove());

    // Create new gif overlay
    const gifOverlay = document.createElement('div');
    gifOverlay.className = 'gif-overlay';
    
    const gifImg = document.createElement('img');
    gifImg.src = gifUrl;
    gifImg.alt = `${keyword} sticker`;
    
    gifOverlay.appendChild(gifImg);
    document.body.appendChild(gifOverlay);

    // Remove the gif after 3 seconds
    setTimeout(() => {
        gifOverlay.classList.add('fade-out');
        setTimeout(() => {
            if (gifOverlay.parentNode) {
                gifOverlay.parentNode.removeChild(gifOverlay);
            }
        }, 500); // Wait for fade-out transition
    }, 3000);
}

function checkForGifKeywords(message) {
    const words = message.toLowerCase().split(/\s+/);
    for (const word of words) {
        if (gifStickers[word]) {
            showGifSticker(word);
            break; // Show only one gif per message
        }
    }
}

// --- Helper Functions ---
function addMessage(data, type = 'user') {
    const messageElement = document.createElement('div');
    messageElement.classList.add('message');
    if (type === 'system') {
        messageElement.classList.add('system');
        messageElement.textContent = data.msg;
    } else if (type === 'error') {
        messageElement.classList.add('error');
        messageElement.textContent = data.msg;
    } else {
        const usernameSpan = document.createElement('span');
        usernameSpan.classList.add('username');
        usernameSpan.textContent = data.username;
        messageElement.appendChild(usernameSpan);
        messageElement.appendChild(document.createTextNode(data.message));
    }
    messagesDiv.appendChild(messageElement);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

function showFeedback(message, type) {
    hostAuthFeedback.textContent = message;
    hostAuthFeedback.className = 'feedback-message ' + type;
    hostAuthFeedback.style.display = 'block';
    setTimeout(() => {
        hostAuthFeedback.style.opacity = '0';
        setTimeout(() => {
            hostAuthFeedback.style.display = 'none';
            hostAuthFeedback.style.opacity = '1';
        }, 500);
    }, 2000);
}

function updateConnectedUsersList(users) {
    connectedUsersList.innerHTML = '';
    for (const sid in users) {
        const userInfo = users[sid];
        const listItem = document.createElement('li');
        let status = '';
        if (userInfo.is_host) status += ' (Host)';
        if (userInfo.is_muted) status += ' (Muted)';
        listItem.textContent = `${sid}: ${userInfo.username}${status}`;
        connectedUsersList.appendChild(listItem);
    }
}

function toggleChatInput(enabled) {
    messageInput.disabled = !enabled;
    sendMessageBtn.disabled = !enabled;
    if (enabled) {
        messageInput.placeholder = "Type your message...";
    } else {
        messageInput.placeholder = "Chat is currently disabled by the host.";
    }
}

// --- Event Listeners ---
sendMessageBtn.addEventListener('click', () => {
    const username = usernameInput.value || 'Anonymous';
    const message = messageInput.value;
    if (message.trim()) {
        socket.emit('message', { username, message });
        messageInput.value = '';
    }
});

messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        sendMessageBtn.click();
    }
});

authenticateHostBtn.addEventListener('click', () => {
    const password = hostPasswordInput.value;
    socket.emit('authenticate_host', { password });
});

toggleMuteBtn.addEventListener('click', () => {
    const targetSid = muteUserIdInput.value;
    if (targetSid) {
        socket.emit('toggle_mute_user', { target_sid: targetSid });
    } else {
        alert('Please enter a User SID to mute/unmute.');
    }
});

toggleChatEnabledBtn.addEventListener('click', () => {
    socket.emit('toggle_chat_enabled', { enabled: !isChatEnabled });
});

// --- Video Sharing Logic ---
let currentVideoBlobUrl = null;

videoFileInput.addEventListener('change', (event) => {
    if (event.target.files.length > 0) {
        const file = event.target.files[0];
        // Revoke previous blob URL to free up memory
        if (currentVideoBlobUrl) URL.revokeObjectURL(currentVideoBlobUrl);
        currentVideoBlobUrl = URL.createObjectURL(file);
        sharedVideo.src = currentVideoBlobUrl;
        sharedVideo.style.display = 'block';
        noVideoMessage.style.display = 'none';
        sharedVideo.load();
    }
});

startVideoShareBtn.addEventListener('click', () => {
    if (isHost && videoFileInput.files.length > 0) {
        const file = videoFileInput.files[0];
        const formData = new FormData();
        formData.append('video', file);

        addMessage({ msg: 'Uploading video...', type: 'system' });

        // Include SID in the URL for basic authentication check on upload endpoint
        // This is a basic check. For production, consider using proper session management
        // and CSRF tokens if this endpoint were exposed without SocketIO's SID mechanism.
        fetch(`/upload_video?sid=${socket.id}`, {
            method: 'POST',
            body: formData,
        })
        .then(response => {
            if (!response.ok) { // Check for HTTP errors
                return response.json().then(errorData => {
                    throw new Error(errorData.error || 'Server error');
                });
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                addMessage({ msg: 'Video uploaded successfully!', type: 'system' });
                socket.emit('host_starts_video_share', { video_url: data.video_url });
            } else {
                addMessage({ msg: 'Video upload failed: ' + data.error, type: 'error' });
            }
        })
        .catch(error => {
            console.error('Error uploading video:', error);
            addMessage({ msg: 'Error uploading video: ' + error.message, type: 'error' });
        });
    } else if (!isHost) {
        alert('Only the host can share videos.');
    } else {
        alert('Please select a video file first.');
    }
});

clearSharedVideoBtn.addEventListener('click', () => {
    if (isHost) {
        socket.emit('host_clears_video');
    } else {
        alert('Only the host can clear shared video.');
    }
});

// Host sending video control commands to synchronize playback
let syncInterval;
sharedVideo.addEventListener('play', () => {
    if (isHost && !syncInterval) {
        socket.emit('host_video_control', { action: 'play', time: sharedVideo.currentTime });
        syncInterval = setInterval(() => {
            if (!sharedVideo.paused) {
                socket.emit('host_video_control', { action: 'seek', time: sharedVideo.currentTime });
            }
        }, 3000); // Sync every 3 seconds
    }
});

sharedVideo.addEventListener('pause', () => {
    if (isHost) {
        socket.emit('host_video_control', { action: 'pause', time: sharedVideo.currentTime });
        if (syncInterval) {
            clearInterval(syncInterval);
            syncInterval = null;
        }
    }
});

sharedVideo.addEventListener('seeked', () => {
    if (isHost) {
        socket.emit('host_video_control', { action: 'seek', time: sharedVideo.currentTime });
    }
});

sharedVideo.addEventListener('ended', () => {
    if (isHost && syncInterval) {
        clearInterval(syncInterval);
        syncInterval = null;
    }
    // Optionally, clear video on host side after it ends
    // socket.emit('host_clears_video'); 
});

// --- Socket.IO Event Handlers ---
socket.on('connect', () => {
    console.log('Connected to server!');
    const mySidElement = document.createElement('p');
    mySidElement.classList.add('my-sid-display');
    mySidElement.textContent = `Your Session ID: ${socket.id}`;
    messagesDiv.prepend(mySidElement); // Add to the top of messages for visibility
    socket.emit('request_initial_state'); // Request initial state on connect
});

socket.on('new_message', (data) => {
    addMessage(data);
    // Check for GIF keywords in the message
    checkForGifKeywords(data.message);
});

socket.on('status', (data) => {
    addMessage(data, 'system');
});

socket.on('host_authenticated', (data) => {
    if (data.success) {
        isHost = true;
        hostVideoControlsDiv.style.display = 'flex';
        hostChatControlsDiv.style.display = 'block';
        showFeedback('You are now authenticated as a host!', 'success');
        socket.emit('request_user_list');
        socket.emit('request_initial_state'); // Re-request initial state to get current video/chat status as host
    } else {
        showFeedback('Host authentication failed: ' + data.error, 'error');
    }
});

socket.on('you_are_muted', () => {
    toggleChatInput(false);
    addMessage({ msg: 'You have been muted by the host. You cannot send messages.', type: 'error' });
});

socket.on('you_are_unmuted', () => {
    // Only re-enable chat input if chat is globally enabled
    // The 'update_chat_status' event will handle the global chat status.
    // This just ensures the personal mute status is reflected.
    socket.emit('get_my_user_status', {});
    addMessage({ msg: 'You have been unmuted by the host. You can now send messages.', type: 'system' });
});


socket.on('update_user_list', (data) => {
    if (isHost) { // Only update if current user is a host
        updateConnectedUsersList(data.users);
    }
});

socket.on('start_video_playback', (data) => {
    if (data.video_url) {
        sharedVideo.src = data.video_url;
        sharedVideo.style.display = 'block';
        noVideoMessage.style.display = 'none';
        sharedVideo.load();
        sharedVideo.play().catch(e => console.error("Video auto-play prevented:", e));
        addMessage({ msg: 'Video playback started by host!', type: 'system' });
    }
});

socket.on('clear_video_playback', () => {
    sharedVideo.pause();
    sharedVideo.src = '';
    sharedVideo.style.display = 'none';
    noVideoMessage.style.display = 'block';
    addMessage({ msg: 'Host has stopped sharing the video.', type: 'system' });
});

socket.on('sync_video_playback', (data) => {
    if (!isHost) { // Only non-hosts should sync
        if (data.action === 'play') {
            sharedVideo.play().catch(e => console.error("Video auto-play prevented:", e));
        } else if (data.action === 'pause') {
            sharedVideo.pause();
        } else if (data.action === 'seek' && data.time !== undefined) {
            // Only seek if difference is significant to avoid constant seeking
            if (Math.abs(sharedVideo.currentTime - data.time) > 1.0) { // Increased threshold slightly
                sharedVideo.currentTime = data.time;
            }
        }
    }
});

socket.on('update_chat_status', (data) => {
    isChatEnabled = data.enabled;
    if (isHost) {
        toggleChatEnabledBtn.textContent = isChatEnabled ? 'Disable Chat for All' : 'Enable Chat for All';
        toggleChatEnabledBtn.className = isChatEnabled ? 'btn btn-warning' : 'btn btn-primary';
    }

    // Determine chat input state based on global chat status and user's mute status
    socket.emit('get_my_user_status', {});
});

socket.on('initial_state', (data) => {
    isChatEnabled = data.chat_enabled;
    const mySid = socket.id;

    // Request user status to update host controls and chat input correctly
    socket.emit('get_my_user_status', {});

    if (data.current_video_url) {
        sharedVideo.src = data.current_video_url;
        sharedVideo.style.display = 'block';
        noVideoMessage.style.display = 'none';
        sharedVideo.load();
        // Don't auto-play on initial load for all, only when initiated by host sync
    } else {
        sharedVideo.style.display = 'none';
        noVideoMessage.style.display = 'block';
    }
});

socket.on('get_my_user_status_response', (data) => {
    isHost = data.is_host; // Update isHost status
    if (isHost) {
         hostVideoControlsDiv.style.display = 'flex';
         hostChatControlsDiv.style.display = 'block';
         toggleChatEnabledBtn.textContent = isChatEnabled ? 'Disable Chat for All' : 'Enable Chat for All';
         toggleChatEnabledBtn.className = isChatEnabled ? 'btn btn-warning' : 'btn btn-primary';
    } else {
        hostVideoControlsDiv.style.display = 'none';
        hostChatControlsDiv.style.display = 'none';
    }

    // Apply chat input state based on host status, mute status, and global chat status
    if (data.is_host) {
        toggleChatInput(true); // Host can always chat
    } else if (data.is_muted) {
        toggleChatInput(false); // Muted users cannot chat
    } else {
        toggleChatInput(isChatEnabled); // Non-muted users follow global chat status
    }

    // Show status messages only for non-hosts when chat status changes
    if (!isHost && !data.is_muted) {
        if (!isChatEnabled) {
            addMessage({ msg: 'Chat has been disabled by the host.', type: 'system' });
        } else {
            addMessage({ msg: 'Chat has been re-enabled by the host.', type: 'system' });
        }
    }
});
"""

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>As Chat - Group Chat</title>
    <style>{css_content}</style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/4.0.0/socket.io.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">As Chat</div>
            <h1>Welcome to Group Chat!</h1>
        </header>

        <main class="main-content">
            <div class="video-panel">
                <h2>Shared Video</h2>
                <div id="videoContainer" class="video-container">
                    <video id="sharedVideo" controls autoplay muted style="display:none;"></video>
                    <p id="noVideoMessage" class="video-placeholder">No video is being shared yet.</p>
                </div>
                <div id="hostVideoControls" class="host-controls-section" style="display: none;">
                    <h3>Video Sharing Controls</h3>
                    <input type="file" id="videoFileInput" accept="video/*" class="file-input">
                    <button id="startVideoShare" class="btn btn-primary">Share Video</button>
                    <button id="clearSharedVideo" class="btn btn-danger">Clear Shared Video</button>
                </div>
            </div>

            <div class="chat-panel">
                <h2>Chat Room</h2>
                <div id="messages" class="message-box">
                    </div>
                <div class="input-area">
                    <input type="text" id="usernameInput" placeholder="Your Name" value="Anonymous" class="text-input">
                    <input type="text" id="messageInput" placeholder="Type your message..." autocomplete="off" class="text-input">
                    <button id="sendMessage" class="btn btn-primary">Send</button>
                </div>
                <div class="host-auth-area">
                    <input type="password" id="hostPasswordInput" placeholder="Host Password" class="text-input">
                    <button id="authenticateHost" class="btn btn-secondary">Become Host</button>
                    <div id="hostAuthFeedback" class="feedback-message" style="display:none;"></div>
                </div>
                <div id="hostChatControls" class="host-controls-section" style="display: none;">
                    <h3>Host Chat Controls</h3>
                    <button id="toggleChatEnabled" class="btn btn-warning">Disable Chat for All</button>
                    <div class="user-mute-controls">
                        <h4>Connected Users (SID: Username):</h4>
                        <ul id="connectedUsersList" class="user-list"></ul>
                        <input type="text" id="muteUserId" placeholder="User SID to Mute/Unmute" class="text-input">
                        <button id="toggleMute" class="btn btn-info">Toggle Mute</button>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>{js_content}</script>
</body>
</html>
"""

# --- Flask Routes ---

@app.route('/')
def index():
    # Render the HTML template by injecting CSS and JS content
    return HTML_TEMPLATE.format(css_content=CSS_CONTENT, js_content=JS_CONTENT)

# --- WebSocket Event Handlers ---

@socketio.on('connect')
def handle_connect():
    sid = request.sid
    print(f"Client connected: {sid}")
    join_room(CHAT_ROOM)
    # Initialize user_info with default values
    if sid not in user_info:
        user_info[sid] = {'username': 'Anonymous', 'is_host': False, 'is_muted': False}
    
    # Send the initial chat_disabled_for_all status to the new user
    emit('update_chat_status', {'enabled': not chat_disabled_for_all}, room=sid)

    # For hosts, update the user list immediately on connect
    for host_sid in hosts:
        emit('update_user_list', {'users': user_info}, room=host_sid)
    
    # Request initial state will be called by client JS
    
@socketio.on('disconnect')
def handle_disconnect():
    sid = request.sid
    # Check if the user was a host, and if so, remove them from the hosts set
    if sid in hosts:
        hosts.remove(sid)
    
    username = user_info.pop(sid, {}).get('username', f'User {sid[:4]}') # Get username before removing
    print(f"Client disconnected: {sid}")
    
    # Remove from muted_users if they were muted
    if sid in muted_users:
        muted_users.remove(sid)

    # Emit a system message about disconnection
    emit('status', {'msg': f'{username} has disconnected.', 'type': 'system'}, room=CHAT_ROOM)

    # Update user list for remaining hosts
    for host_sid in hosts:
        emit('update_user_list', {'users': user_info}, room=host_sid)


@socketio.on('message')
def handle_message(data):
    sid = request.sid
    username = data.get('username', 'Anonymous')
    message = data.get('message', '')
    
    # Update username in user_info if changed by client
    if sid in user_info:
        user_info[sid]['username'] = username

    is_host = sid in hosts
    is_muted = sid in muted_users

    if not message.strip():
        emit('status', {'msg': 'Message cannot be empty.', 'type': 'error'}, room=sid)
        return

    if chat_disabled_for_all and not is_host:
        emit('status', {'msg': 'Chat is currently disabled by the host.', 'type': 'error'}, room=sid)
        return

    if is_muted and not is_host: 
        emit('status', {'msg': 'You are currently muted and cannot send messages.', 'type': 'error'}, room=sid)
        return

    print(f"Message from {username} ({sid}): {message}")
    emit('new_message', {'username': username, 'message': message}, room=CHAT_ROOM)


@socketio.on('authenticate_host')
def authenticate_host(data):
    sid = request.sid
    password = data.get('password')
    if password == HOST_PASSWORD:
        hosts.add(sid)
        if sid in user_info:
            user_info[sid]['is_host'] = True
        emit('host_authenticated', {'success': True}, room=sid)
        username = user_info.get(sid, {}).get('username', sid)
        emit('status', {'msg': f'User {username} is now a host.', 'type': 'system'}, room=CHAT_ROOM)
        print(f"User {sid} authenticated as host.")
        for host_sid in hosts:
            emit('update_user_list', {'users': user_info}, room=host_sid)
    else:
        emit('host_authenticated', {'success': False, 'error': 'Invalid password'}, room=sid)
        print(f"User {sid} failed host authentication.")

@socketio.on('toggle_mute_user')
def toggle_mute_user(data):
    sid = request.sid
    if sid not in hosts:
        emit('status', {'msg': 'Permission denied: Only hosts can mute users.', 'type': 'error'}, room=sid)
        return

    target_sid = data.get('target_sid')
    if target_sid in user_info and target_sid != sid: # Cannot mute self
        target_username = user_info[target_sid]['username']
        if target_sid in hosts: # Prevent muting other hosts
            emit('status', {'msg': f'Cannot mute host "{target_username}".', 'type': 'error'}, room=sid)
            return

        if target_sid in muted_users:
            muted_users.remove(target_sid)
            user_info[target_sid]['is_muted'] = False
            emit('status', {'msg': f'User {target_username} has been unmuted by host.', 'type': 'system'}, room=CHAT_ROOM)
            emit('you_are_unmuted', room=target_sid)
            print(f"User {target_sid} unmuted by host {user_info.get(sid,{}).get('username',sid)}.")
        else:
            muted_users.add(target_sid)
            user_info[target_sid]['is_muted'] = True
            emit('status', {'msg': f'User {target_username} has been muted by host.', 'type': 'system'}, room=CHAT_ROOM)
            emit('you_are_muted', room=target_sid)
            print(f"User {target_sid} muted by host {user_info.get(sid,{}).get('username',sid)}.")
        
        for host_sid in hosts:
            emit('update_user_list', {'users': user_info}, room=host_sid)
    elif target_sid == sid:
        emit('status', {'msg': 'You cannot mute yourself.', 'type': 'error'}, room=sid)
    else:
        emit('status', {'msg': f'User {target_sid} not found or invalid.', 'type': 'error'}, room=sid)

@socketio.on('request_user_list')
def request_user_list():
    sid = request.sid
    if sid in hosts:
        emit('update_user_list', {'users': user_info}, room=sid)

@socketio.on('toggle_chat_enabled')
def toggle_chat_enabled(data):
    sid = request.sid
    global chat_disabled_for_all
    if sid not in hosts:
        emit('status', {'msg': 'Permission denied: Only hosts can toggle chat.', 'type': 'error'}, room=sid)
        return
    
    # Data.get('enabled') reflects the *new* state (true for enabled, false for disabled)
    new_chat_status = data.get('enabled') 
    chat_disabled_for_all = not new_chat_status # Invert because our flag means "disabled"

    status_msg = "enabled" if new_chat_status else "disabled"
    emit('status', {'msg': f'Host has {status_msg} chat for all non-hosts.', 'type': 'system'}, room=CHAT_ROOM)
    
    emit('update_chat_status', {'enabled': new_chat_status}, room=CHAT_ROOM) # Send the client-friendly "enabled" state
    
    # No need to iterate and set chat_disabled in user_info for each user as it's a global flag now.
    # The client-side 'update_chat_status' listener will handle UI updates.

    for host_sid in hosts:
        emit('update_user_list', {'users': user_info}, room=host_sid)

@socketio.on('request_initial_state')
def request_initial_state():
    sid = request.sid
    video_url_to_send = None
    if current_shared_video_server_path:
        video_url_to_send = f"/videos/{os.path.basename(current_shared_video_server_path)}"
        
    emit('initial_state', {
        'chat_enabled': not chat_disabled_for_all,
        'current_video_url': video_url_to_send,
        'is_host_password_set': bool(HOST_PASSWORD) # Indicate if host password is set for UI
    }, room=sid)

@socketio.on('get_my_user_status')
def get_my_user_status(data):
    sid = request.sid
    status = user_info.get(sid, {'username': 'Anonymous', 'is_host': False, 'is_muted': False})
    emit('get_my_user_status_response', status, room=sid)

# --- Video Sharing Backend (Server-Relayed) ---

@app.route('/upload_video', methods=['POST'])
def upload_video():
    # Simple check for host status via SID in query param for HTTP endpoint
    # A more robust solution for production would use Flask-Login or similar for session management.
    requester_sid = request.args.get('sid')
    if requester_sid not in hosts:
        return json.dumps({'success': False, 'error': 'Permission denied: Not a host'}), 403

    if 'video' not in request.files:
        return json.dumps({'success': False, 'error': 'No video file provided'}), 400

    video_file = request.files['video']
    if video_file.filename == '':
        return json.dumps({'success': False, 'error': 'No selected file'}), 400

    if video_file:
        global current_shared_video_server_path
        # Clear existing uploads before saving new one
        # This is a simple approach. For production, consider proper file management
        # to avoid race conditions or accidental deletion of needed files.
        if os.path.exists(UPLOAD_FOLDER):
            # Ensure the directory is empty but exists
            for item in os.listdir(UPLOAD_FOLDER):
                item_path = os.path.join(UPLOAD_FOLDER, item)
                if os.path.isfile(item_path):
                    os.unlink(item_path)
                elif os.path.isdir(item_path):
                    shutil.rmtree(item_path)
        else:
            os.makedirs(UPLOAD_FOLDER)

        # Sanitize filename to prevent directory traversal attacks
        filename = secure_filename(video_file.filename)
        # Add a unique prefix to prevent name collisions
        filename = f"shared_video_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}_{filename}"
        file_path = os.path.join(UPLOAD_FOLDER, filename)
        video_file.save(file_path)
        current_shared_video_server_path = file_path
        
        video_url = f"/videos/{filename}"
        return json.dumps({'success': True, 'video_url': video_url}), 200
    
    return json.dumps({'success': False, 'error': 'Unknown error during upload'}), 500

# Helper for secure filenames
from werkzeug.utils import secure_filename

@app.route('/videos/<filename>')
def serve_video(filename):
    file_path = os.path.join(UPLOAD_FOLDER, filename)
    # Basic security: ensure the requested filename is within the UPLOAD_FOLDER
    # and doesn't try to access files outside it.
    if not os.path.exists(file_path) or not os.path.commonprefix([file_path, UPLOAD_FOLDER]) == UPLOAD_FOLDER:
        return "Video not found", 404

    range_header = request.headers.get('Range', None)
    if not range_header:
        # If no range header, serve the whole file directly
        return send_from_directory(UPLOAD_FOLDER, filename, mimetype='video/mp4')

    size = os.path.getsize(file_path)
    byte1, byte2 = 0, size - 1

    # Using a more robust regex for range parsing
    match = re.search(r'bytes=(\d+)-(\d*)', range_header)
    if not match:
        return "Invalid Range header", 416 # Requested Range Not Satisfiable

    g = match.groups()

    if g[0]: byte1 = int(g[0])
    if g[1]: byte2 = int(g[1]) if g[1] else size - 1

    length = byte2 - byte1 + 1
    
    resp_data = None
    try:
        with open(file_path, 'rb') as f:
            f.seek(byte1)
            resp_data = f.read(length)
    except IOError:
        return "Internal Server Error", 500

    resp = Response(resp_data, 206, mimetype='video/mp4',
                    headers={'Content-Range': f'bytes {byte1}-{byte2}/{size}',
                             'Accept-Ranges': 'bytes'})
    return resp

@socketio.on('host_starts_video_share')
def host_starts_video_share(data):
    sid = request.sid
    if sid not in hosts:
        emit('status', {'msg': 'Permission denied: Only hosts can share video.', 'type': 'error'}, room=sid)
        return
    
    video_url = data.get('video_url', '')
    if video_url:
        emit('start_video_playback', {'video_url': video_url}, room=CHAT_ROOM)
        emit('status', {'msg': f'Host is sharing a video!', 'type': 'system'}, room=CHAT_ROOM)
        print(f"Host {sid} starting video share: {video_url}")
    else:
        emit('status', {'msg': 'No video URL provided for sharing.', 'type': 'error'}, room=sid)

@socketio.on('host_clears_video')
def host_clears_video():
    sid = request.sid
    if sid not in hosts:
        emit('status', {'msg': 'Permission denied: Only hosts can clear video.', 'type': 'error'}, room=sid)
        return
    
    global current_shared_video_server_path
    current_shared_video_server_path = None
    
    # Safely clear the upload directory contents
    if os.path.exists(UPLOAD_FOLDER):
        for item in os.listdir(UPLOAD_FOLDER):
            item_path = os.path.join(UPLOAD_FOLDER, item)
            try:
                if os.path.isfile(item_path) or os.path.islink(item_path):
                    os.unlink(item_path)
                elif os.path.isdir(item_path):
                    shutil.rmtree(item_path)
            except Exception as e:
                print(f'Failed to delete {item_path}. Reason: {e}')

    emit('clear_video_playback', room=CHAT_ROOM)
    emit('status', {'msg': f'Host has stopped sharing the video.', 'type': 'system'}, room=CHAT_ROOM)

@socketio.on('host_video_control')
def host_video_control(data):
    sid = request.sid
    if sid not in hosts:
        return
    emit('sync_video_playback', data, room=CHAT_ROOM, include_self=False)

if __name__ == '__main__':
    # For production, you should use a production-ready WSGI server like Gunicorn
    # along with an asynchronous worker like eventlet or gevent.
    # Example command for Gunicorn:
    # gunicorn -k eventlet -w 1 main:app --bind 0.0.0.0:5000
    # Or, if you need to run the SocketIO server directly:
    # gunicorn -k geventwebsocket.gunicorn.workers.GeventWebSocketWorker -w 1 main:app --bind 0.0.0.0:5000
    
    # The 'allow_unsafe_werkzeug=True' is for development and should be removed in production.
    # debug=True should also be False in production for security and performance.
    socketio.run(app, debug=False, host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))